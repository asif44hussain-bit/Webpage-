"use client";

import Link from "next/link";
import Image from "next/image";
import { useEffect, useState } from "react";
import { useCartStore } from "@/lib/cart-store";
import { formatINR } from "@/lib/money";

export default function CartPage() {
  const [mounted, setMounted] = useState(false);
  const items = useCartStore((s) => s.items);
  const removeItem = useCartStore((s) => s.removeItem);
  const setQuantity = useCartStore((s) => s.setQuantity);
  const subtotal = useCartStore((s) => s.subtotalInPaise());

  useEffect(() => setMounted(true), []);

  if (!mounted) return null;

  return (
    <div className="container-ck py-14 sm:py-20">
      <div className="mb-10">
        <p className="eyebrow mb-2">Your bag</p>
        <h1 className="font-display text-4xl tracking-tightest sm:text-6xl">CART</h1>
      </div>

      {items.length === 0 ? (
        <div className="flex flex-col items-start gap-6 py-16">
          <p className="max-w-[38ch] text-ink/60">
            Your cart is empty. There&apos;s exactly one product live right now — go take a look.
          </p>
          <Link href="/shop" className="btn-primary">Shop the Drop</Link>
        </div>
      ) : (
        <div className="grid gap-12 lg:grid-cols-3">
          <div className="divide-y divide-ink/10 lg:col-span-2">
            {items.map((item) => (
              <div key={`${item.productId}-${item.size}`} className="flex gap-5 py-6">
                <div className="relative h-28 w-24 shrink-0 overflow-hidden bg-concrete/20">
                  {item.image && (
                    <Image src={item.image} alt={item.name} fill unoptimized className="object-cover" />
                  )}
                </div>
                <div className="flex flex-1 flex-col justify-between">
                  <div className="flex justify-between gap-4">
                    <div>
                      <Link href={`/product/${item.slug}`} className="font-medium hover:text-signal">
                        {item.name}
                      </Link>
                      <p className="spec-tag mt-1">Size {item.size} · {item.sku}</p>
                    </div>
                    <p className="font-mono text-sm">{formatINR(item.unitPriceInPaise * item.quantity)}</p>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="flex items-center border border-ink/20">
                      <button
                        className="px-3 py-1 font-mono text-sm"
                        onClick={() => setQuantity(item.productId, item.size, item.quantity - 1)}
                        aria-label="Decrease quantity"
                      >
                        −
                      </button>
                      <span className="px-3 font-mono text-sm">{item.quantity}</span>
                      <button
                        className="px-3 py-1 font-mono text-sm"
                        onClick={() => setQuantity(item.productId, item.size, item.quantity + 1)}
                        aria-label="Increase quantity"
                      >
                        +
                      </button>
                    </div>
                    <button
                      onClick={() => removeItem(item.productId, item.size)}
                      className="spec-tag hover:text-signal"
                    >
                      Remove
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="h-fit border border-ink/10 p-6">
            <div className="flex justify-between font-mono text-sm">
              <span className="text-ink/60">Subtotal</span>
              <span>{formatINR(subtotal)}</span>
            </div>
            <p className="mt-2 text-xs text-ink/50">Shipping &amp; taxes calculated at checkout.</p>
            <Link href="/checkout" className="btn-primary mt-6 w-full">
              Checkout
            </Link>
          </div>
        </div>
      )}
    </div>
  );
}
