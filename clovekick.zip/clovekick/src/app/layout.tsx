import type { Metadata } from "next";
import { Archivo_Black, Inter, JetBrains_Mono } from "next/font/google";
import "./globals.css";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

const display = Archivo_Black({
  subsets: ["latin"],
  weight: "400",
  variable: "--font-display",
  display: "swap",
});

const body = Inter({
  subsets: ["latin"],
  variable: "--font-body",
  display: "swap",
});

const mono = JetBrains_Mono({
  subsets: ["latin"],
  variable: "--font-mono",
  display: "swap",
});

const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || "https://clovekick.com";
const storeName = process.env.NEXT_PUBLIC_STORE_NAME || "CLOVEKICK";

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: {
    default: `${storeName}® — Wear the Energy`,
    template: `%s — ${storeName}®`,
  },
  description:
    "Original streetwear. Limited drops. Only one product ships at a time — everything else lives permanently in The Archive.",
  keywords: ["streetwear", "CLOVEKICK", "limited drop", "India streetwear", "original fashion"],
  openGraph: {
    title: `${storeName}® — Wear the Energy`,
    description: "Original streetwear. Limited drops.",
    url: siteUrl,
    siteName: storeName,
    locale: "en_IN",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: `${storeName}® — Wear the Energy`,
    description: "Original streetwear. Limited drops.",
  },
  robots: { index: true, follow: true },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${display.variable} ${body.variable} ${mono.variable}`}>
      <body className="flex min-h-screen flex-col">
        <Header />
        <main className="flex-1">{children}</main>
        <Footer />
      </body>
    </html>
  );
}
