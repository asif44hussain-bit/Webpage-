import { listProducts, getCategories } from "@/lib/products";
import ProductCard from "@/components/ProductCard";
import ShopFilters from "@/components/ShopFilters";
import type { Metadata } from "next";
import type { SortOption } from "@/lib/products";

export const metadata: Metadata = {
  title: "Shop",
  description: "Browse the current drop and the full CLOVEKICK archive.",
};

export default async function ShopPage({
  searchParams,
}: {
  searchParams: { q?: string; category?: string; sort?: string };
}) {
  const [products, categories] = await Promise.all([
    listProducts({
      q: searchParams.q,
      category: searchParams.category,
      sort: (searchParams.sort as SortOption) ?? "newest",
    }),
    getCategories(),
  ]);

  return (
    <div className="container-ck py-14 sm:py-20">
      <div className="mb-10">
        <p className="eyebrow mb-2">Full catalog</p>
        <h1 className="font-display text-4xl tracking-tightest sm:text-6xl">SHOP</h1>
      </div>

      <ShopFilters categories={categories} />

      {products.length === 0 ? (
        <div className="py-20 text-center">
          <p className="font-mono text-sm uppercase tracking-widest2 text-concrete-dark">
            No products match that search.
          </p>
        </div>
      ) : (
        <>
          <p className="spec-tag mb-6">{products.length} product{products.length !== 1 ? "s" : ""}</p>
          <div className="grid grid-cols-2 gap-x-5 gap-y-10 sm:grid-cols-3 lg:grid-cols-4">
            {products.map((p) => (
              <ProductCard key={p.id} product={p as any} />
            ))}
          </div>
        </>
      )}
    </div>
  );
}
