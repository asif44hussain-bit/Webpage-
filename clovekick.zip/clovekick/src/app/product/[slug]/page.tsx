import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { getProductBySlug, getRelatedProducts } from "@/lib/products";
import { formatINR } from "@/lib/money";
import ProductGallery from "@/components/ProductGallery";
import AddToCartPanel from "@/components/AddToCartPanel";
import ProductCard from "@/components/ProductCard";

interface Props {
  params: { slug: string };
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const product = await getProductBySlug(params.slug);
  if (!product) return {};
  return {
    title: product.name,
    description: product.description,
    openGraph: {
      title: product.name,
      description: product.description,
      images: product.images[0] ? [{ url: product.images[0].url }] : undefined,
    },
  };
}

export default async function ProductPage({ params }: Props) {
  const product = await getProductBySlug(params.slug);
  if (!product) notFound();

  const related = await getRelatedProducts(product.category, product.id);
  const soldOut = product.status !== "LIVE";

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Product",
    name: product.name,
    description: product.description,
    sku: product.sku,
    category: product.category,
    image: product.images.map((i) => i.url),
    offers: {
      "@type": "Offer",
      priceCurrency: "INR",
      price: (product.priceInPaise / 100).toFixed(2),
      availability: soldOut
        ? "https://schema.org/SoldOut"
        : "https://schema.org/InStock",
    },
  };

  return (
    <div className="container-ck py-10 sm:py-16">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />

      <nav className="spec-tag mb-8">
        <a href="/shop" className="hover:text-signal">Shop</a> / {product.category} / {product.name}
      </nav>

      <div className="grid gap-10 lg:grid-cols-2 lg:gap-16">
        <ProductGallery images={product.images} soldOut={soldOut} />

        <div>
          <p className="spec-tag">{product.category} · {product.sku}</p>
          <h1 className="mt-3 font-display text-3xl tracking-tightest sm:text-5xl">{product.name}</h1>
          <p className="mt-5 font-mono text-2xl">{formatINR(product.priceInPaise)}</p>

          <p className="mt-6 max-w-[54ch] leading-relaxed text-ink/70">{product.description}</p>
          {product.story && (
            <p className="mt-3 max-w-[54ch] text-sm italic text-ink/50">{product.story}</p>
          )}

          <div className="mt-10 border-t border-ink/10 pt-8">
            <AddToCartPanel
              productId={product.id}
              slug={product.slug}
              name={product.name}
              sku={product.sku}
              sizes={product.sizes}
              unitPriceInPaise={product.priceInPaise}
              image={product.images[0]?.url ?? ""}
              status={product.status}
            />
          </div>

          <dl className="mt-10 space-y-2 border-t border-ink/10 pt-6 font-mono text-xs">
            <div className="flex justify-between text-ink/50">
              <dt>Status</dt>
              <dd className="text-ink">{product.status === "LIVE" ? "Live — shipping now" : "Archived"}</dd>
            </div>
            <div className="flex justify-between text-ink/50">
              <dt>SKU</dt>
              <dd className="text-ink">{product.sku}</dd>
            </div>
            <div className="flex justify-between text-ink/50">
              <dt>Drop No.</dt>
              <dd className="text-ink">{String(product.dropNumber).padStart(3, "0")}</dd>
            </div>
          </dl>
        </div>
      </div>

      {related.length > 0 && (
        <section className="mt-24 border-t border-ink/10 pt-12">
          <p className="eyebrow mb-2">More from the archive</p>
          <h2 className="mb-8 font-display text-2xl tracking-tightest sm:text-3xl">RELATED</h2>
          <div className="grid grid-cols-2 gap-x-5 gap-y-10 sm:grid-cols-4">
            {related.map((p) => (
              <ProductCard key={p.id} product={p as any} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
