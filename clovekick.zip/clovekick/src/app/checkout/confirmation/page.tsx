import Link from "next/link";

export default function ConfirmationPage({
  searchParams,
}: {
  searchParams: { order?: string };
}) {
  return (
    <div className="container-ck flex min-h-[60vh] flex-col items-start justify-center py-20">
      <p className="eyebrow mb-4">Order placed</p>
      <h1 className="font-display text-4xl tracking-tightest sm:text-6xl">THANK YOU.</h1>
      {searchParams.order && (
        <p className="mt-6 font-mono text-sm text-ink/60">
          Order reference: <span className="text-ink">{searchParams.order}</span>
        </p>
      )}
      <p className="mt-3 max-w-[46ch] text-ink/60">
        We&apos;ve recorded your order and will follow up by email with shipping and payment details.
      </p>
      <Link href="/shop" className="btn-primary mt-8">Continue Shopping</Link>
    </div>
  );
}
