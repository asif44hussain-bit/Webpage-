"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { useCartStore } from "@/lib/cart-store";
import { formatINR } from "@/lib/money";

const FIELDS = [
  { name: "name", label: "Full Name", type: "text", autoComplete: "name" },
  { name: "email", label: "Email", type: "email", autoComplete: "email" },
  { name: "phone", label: "Phone", type: "tel", autoComplete: "tel" },
  { name: "address", label: "Shipping Address", type: "text", autoComplete: "street-address" },
  { name: "city", label: "City", type: "text", autoComplete: "address-level2" },
  { name: "state", label: "State", type: "text", autoComplete: "address-level1" },
  { name: "pincode", label: "PIN Code", type: "text", autoComplete: "postal-code" },
] as const;

type FormState = Record<(typeof FIELDS)[number]["name"], string>;

export default function CheckoutPage() {
  const [mounted, setMounted] = useState(false);
  const items = useCartStore((s) => s.items);
  const subtotal = useCartStore((s) => s.subtotalInPaise());
  const clear = useCartStore((s) => s.clear);
  const router = useRouter();

  const [form, setForm] = useState<FormState>({
    name: "", email: "", phone: "", address: "", city: "", state: "", pincode: "",
  });
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => setMounted(true), []);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    setError(null);
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ customer: form, items }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Could not place order.");
      clear();
      router.push(`/checkout/confirmation?order=${data.orderNumber}`);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  }

  if (!mounted) return null;

  if (items.length === 0) {
    return (
      <div className="container-ck py-20 text-center">
        <p className="mb-6 text-ink/60">Your cart is empty — nothing to check out yet.</p>
        <Link href="/shop" className="btn-primary">Shop the Drop</Link>
      </div>
    );
  }

  return (
    <div className="container-ck py-14 sm:py-20">
      <div className="mb-10">
        <p className="eyebrow mb-2">Almost there</p>
        <h1 className="font-display text-4xl tracking-tightest sm:text-6xl">CHECKOUT</h1>
      </div>

      <div className="grid gap-12 lg:grid-cols-3">
        <form onSubmit={handleSubmit} className="space-y-5 lg:col-span-2">
          {FIELDS.map((f) => (
            <div key={f.name}>
              <label htmlFor={f.name} className="spec-tag mb-2 block">{f.label}</label>
              <input
                id={f.name}
                name={f.name}
                type={f.type}
                autoComplete={f.autoComplete}
                required
                value={form[f.name]}
                onChange={(e) => setForm((s) => ({ ...s, [f.name]: e.target.value }))}
                className="w-full border border-ink/20 bg-transparent px-4 py-3 text-sm outline-none focus:border-ink"
              />
            </div>
          ))}

          <div className="border border-ink/10 bg-concrete/10 p-4 text-xs text-ink/60">
            Payment gateway is not yet connected — this places a pending order. We&apos;ll wire up an Indian
            payment provider once business/KYC verification is complete.
          </div>

          {error && <p className="text-sm text-signal">{error}</p>}

          <button type="submit" disabled={submitting} className="btn-primary w-full sm:w-auto">
            {submitting ? "Placing Order…" : "Place Order"}
          </button>
        </form>

        <div className="h-fit border border-ink/10 p-6">
          <p className="spec-tag mb-4">Order Summary</p>
          <div className="space-y-3">
            {items.map((item) => (
              <div key={`${item.productId}-${item.size}`} className="flex justify-between text-sm">
                <span className="text-ink/70">{item.name} ({item.size}) × {item.quantity}</span>
                <span className="font-mono">{formatINR(item.unitPriceInPaise * item.quantity)}</span>
              </div>
            ))}
          </div>
          <div className="mt-4 flex justify-between border-t border-ink/10 pt-4 font-mono text-sm">
            <span>Subtotal</span>
            <span>{formatINR(subtotal)}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
