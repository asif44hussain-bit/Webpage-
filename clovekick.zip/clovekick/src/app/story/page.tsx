import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Story",
  description: "Why CLOVEKICK only ever sells one product at a time.",
};

export default function StoryPage() {
  return (
    <div className="container-ck py-14 sm:py-24">
      <p className="eyebrow mb-4">The idea</p>
      <h1 className="max-w-[16ch] font-display text-4xl leading-[0.95] tracking-tightest sm:text-6xl">
        ONE DROP. NO RESTOCK. EVERY PIECE ARCHIVED.
      </h1>

      <div className="mt-16 grid gap-12 lg:grid-cols-2">
        <p className="max-w-[54ch] text-lg leading-relaxed text-ink/70">
          Most stores sell everything, all the time, until it feels like nothing. CLOVEKICK does the opposite:
          one product live, one shot to get it, then it&apos;s gone. Every past drop stays visible in
          The Archive — sold out, unreissued, permanently on the record. It&apos;s not a marketing gimmick.
          It&apos;s how the brand is built: scarcity by design, not by accident.
        </p>
        <p className="max-w-[54ch] text-lg leading-relaxed text-ink/70">
          Each piece is developed in small batches, cut and finished before it&apos;s ever listed, and
          photographed the way it&apos;ll actually be worn. When it sells out, we don&apos;t bring it back.
          We move to the next one. That&apos;s the whole model.
        </p>
      </div>

      <div className="mt-20 grid gap-8 border-t border-ink/10 pt-12 sm:grid-cols-3">
        {[
          { n: "01", t: "Design", d: "Every silhouette is developed in-house, sample-checked before it ships." },
          { n: "02", t: "Drop", d: "One product goes live. No pre-orders, no waitlists, no restocks." },
          { n: "03", t: "Archive", d: "Once it sells out, it's retired to The Archive — permanently." },
        ].map((s) => (
          <div key={s.n}>
            <p className="font-mono text-xs text-concrete-dark">{s.n}</p>
            <h3 className="mt-2 font-display text-xl tracking-tightest">{s.t}</h3>
            <p className="mt-2 text-sm text-ink/60">{s.d}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
