import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/auth";
import { listProducts, type SortOption } from "@/lib/products";

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const products = await listProducts({
    q: searchParams.get("q") ?? undefined,
    category: searchParams.get("category") ?? undefined,
    sort: (searchParams.get("sort") as SortOption) ?? "newest",
  });
  return NextResponse.json({ products });
}

export async function POST(req: NextRequest) {
  const admin = await requireAdmin();
  if (!admin) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const body = await req.json();
  const { name, sku, description, priceInPaise, category, sizes, images, status, dropNumber, stockCount, story } = body;

  if (!name || !sku || !description || !priceInPaise || !category || !Array.isArray(sizes)) {
    return NextResponse.json({ error: "Missing required fields." }, { status: 400 });
  }

  const slug = slugify(name);

  try {
    const product = await prisma.product.create({
      data: {
        name,
        sku,
        slug,
        description,
        story: story || null,
        priceInPaise: Number(priceInPaise),
        category,
        sizes,
        status: status || "SOLD_OUT",
        dropNumber: dropNumber ?? 0,
        stockCount: stockCount ?? 0,
        images: {
          create: (images || []).map((url: string, i: number) => ({
            url,
            alt: `${name} — CLOVEKICK`,
            position: i,
          })),
        },
      },
    });

    // Enforce single-LIVE invariant if this new product was created as LIVE.
    if (product.status === "LIVE") {
      await prisma.product.updateMany({
        where: { status: "LIVE", id: { not: product.id } },
        data: { status: "SOLD_OUT" },
      });
    }

    return NextResponse.json({ product }, { status: 201 });
  } catch (err: any) {
    if (err.code === "P2002") {
      return NextResponse.json({ error: "A product with that name/SKU already exists." }, { status: 409 });
    }
    return NextResponse.json({ error: "Could not create product." }, { status: 500 });
  }
}

function slugify(name: string) {
  return name
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "") + "-" + Math.random().toString(36).slice(2, 6);
}
