import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/auth";

export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  const product = await prisma.product.findUnique({
    where: { id: params.id },
    include: { images: { orderBy: { position: "asc" } } },
  });
  if (!product) return NextResponse.json({ error: "Not found" }, { status: 404 });
  return NextResponse.json({ product });
}

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const admin = await requireAdmin();
  if (!admin) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const body = await req.json();
  const { name, description, story, priceInPaise, category, sizes, status, stockCount, images } = body;

  const data: any = {};
  if (name !== undefined) data.name = name;
  if (description !== undefined) data.description = description;
  if (story !== undefined) data.story = story;
  if (priceInPaise !== undefined) data.priceInPaise = Number(priceInPaise);
  if (category !== undefined) data.category = category;
  if (sizes !== undefined) data.sizes = sizes;
  if (stockCount !== undefined) data.stockCount = Number(stockCount);

  try {
    // Handle image replacement separately (delete + recreate) if provided.
    if (Array.isArray(images)) {
      await prisma.productImage.deleteMany({ where: { productId: params.id } });
      data.images = {
        create: images.map((url: string, i: number) => ({
          url,
          alt: `${name ?? "CLOVEKICK product"} image`,
          position: i,
        })),
      };
    }

    // Status changes go through the single-LIVE-invariant transaction below
    // instead of a plain update, when marking something LIVE.
    if (status === "LIVE") {
      const product = await prisma.$transaction(async (tx) => {
        await tx.product.updateMany({
          where: { status: "LIVE", id: { not: params.id } },
          data: { status: "SOLD_OUT" },
        });
        return tx.product.update({
          where: { id: params.id },
          data: { ...data, status: "LIVE" },
          include: { images: true },
        });
      });
      return NextResponse.json({ product });
    }

    if (status !== undefined) data.status = status;

    const product = await prisma.product.update({
      where: { id: params.id },
      data,
      include: { images: true },
    });
    return NextResponse.json({ product });
  } catch (err) {
    return NextResponse.json({ error: "Could not update product." }, { status: 500 });
  }
}

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  const admin = await requireAdmin();
  if (!admin) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  try {
    await prisma.product.delete({ where: { id: params.id } });
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ error: "Could not delete product." }, { status: 500 });
  }
}
