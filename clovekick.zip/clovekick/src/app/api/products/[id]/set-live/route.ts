import { NextRequest, NextResponse } from "next/server";
import { requireAdmin } from "@/lib/auth";
import { setProductLive } from "@/lib/products";

export async function POST(_req: NextRequest, { params }: { params: { id: string } }) {
  const admin = await requireAdmin();
  if (!admin) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  try {
    const product = await setProductLive(params.id);
    return NextResponse.json({ product });
  } catch {
    return NextResponse.json({ error: "Could not mark product live." }, { status: 500 });
  }
}
