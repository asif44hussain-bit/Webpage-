import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/auth";

interface CheckoutItem {
  productId: string;
  size: string;
  quantity: number;
}

export async function POST(req: NextRequest) {
  const body = await req.json();
  const { customer, items } = body as {
    customer: { name: string; email: string; phone: string; address: string; city: string; state: string; pincode: string };
    items: CheckoutItem[];
  };

  if (!customer?.name || !customer?.email || !customer?.phone || !customer?.address || !customer?.city || !customer?.state || !customer?.pincode) {
    return NextResponse.json({ error: "Please fill in every shipping field." }, { status: 400 });
  }
  if (!Array.isArray(items) || items.length === 0) {
    return NextResponse.json({ error: "Your cart is empty." }, { status: 400 });
  }

  // Server-side enforcement: only the currently LIVE product may be ordered,
  // no matter what the client sent.
  const productIds = [...new Set(items.map((i) => i.productId))];
  const products = await prisma.product.findMany({ where: { id: { in: productIds } } });
  const byId = new Map(products.map((p) => [p.id, p]));

  for (const item of items) {
    const product = byId.get(item.productId);
    if (!product || product.status !== "LIVE") {
      return NextResponse.json(
        { error: "One or more items in your cart are no longer available for purchase." },
        { status: 409 }
      );
    }
  }

  const subtotalInPaise = items.reduce((sum, item) => {
    const product = byId.get(item.productId)!;
    return sum + product.priceInPaise * item.quantity;
  }, 0);

  const orderNumber = `CK-${Date.now().toString(36).toUpperCase()}`;

  const order = await prisma.order.create({
    data: {
      orderNumber,
      subtotalInPaise,
      status: "PENDING",
      customer: {
        create: {
          name: customer.name,
          email: customer.email,
          phone: customer.phone,
          address: customer.address,
          city: customer.city,
          state: customer.state,
          pincode: customer.pincode,
        },
      },
      items: {
        create: items.map((item) => {
          const product = byId.get(item.productId)!;
          return {
            productId: item.productId,
            size: item.size,
            quantity: item.quantity,
            unitPriceInPaise: product.priceInPaise,
            nameSnapshot: product.name,
          };
        }),
      },
    },
  });

  return NextResponse.json({ orderNumber: order.orderNumber }, { status: 201 });
}

export async function GET() {
  const admin = await requireAdmin();
  if (!admin) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const orders = await prisma.order.findMany({
    orderBy: { createdAt: "desc" },
    include: { customer: true, items: true },
  });
  return NextResponse.json({ orders });
}
