import Link from "next/link";
import Image from "next/image";
import { getLiveProduct, listProducts } from "@/lib/products";
import { formatINR } from "@/lib/money";
import ProductCard from "@/components/ProductCard";

export const revalidate = 30;

export default async function HomePage() {
  const [live, archive] = await Promise.all([
    getLiveProduct(),
    listProducts({ sort: "newest" }),
  ]);
  const archiveOnly = archive.filter((p) => p.status === "SOLD_OUT").slice(0, 24);

  return (
    <>
      {/* HERO */}
      <section className="container-ck flex min-h-[86vh] flex-col justify-center border-b border-ink/10 py-16">
        <p className="eyebrow mb-6 animate-fadeUp">Drop {String(live?.dropNumber ?? 0).padStart(3, "0")} — Live now</p>
        <h1
          className="animate-fadeUp font-display text-[15vw] leading-[0.86] tracking-tightest sm:text-[9vw] lg:text-[7.2vw]"
          style={{ animationDelay: "0.08s" }}
        >
          WEAR THE
          <br />
          ENERGY.
        </h1>
        <div
          className="mt-8 flex animate-fadeUp flex-col items-start gap-6 sm:flex-row sm:items-center sm:justify-between"
          style={{ animationDelay: "0.18s" }}
        >
          <p className="max-w-[34ch] text-base text-ink/70 sm:text-lg">
            Original streetwear. Limited drops. One product live at a time — everything else is archived, not restocked.
          </p>
          <Link href="#drop" className="btn-primary shrink-0">
            Shop the Drop
          </Link>
        </div>
      </section>

      {/* LIVE PRODUCT */}
      <section id="drop" className="container-ck border-b border-ink/10 py-16 sm:py-24">
        <div className="mb-10 flex items-end justify-between">
          <div>
            <p className="eyebrow mb-2">Currently live</p>
            <h2 className="font-display text-3xl tracking-tightest sm:text-5xl">THE DROP</h2>
          </div>
          <span className="hidden font-mono text-xs text-concrete-dark sm:block">01 / 01 — only one at a time</span>
        </div>

        {live ? (
          <div className="grid gap-10 lg:grid-cols-2 lg:gap-16">
            <div className="relative aspect-[4/5] overflow-hidden bg-concrete/20">
              {live.images[0] && (
                <Image
                  src={live.images[0].url}
                  alt={live.images[0].alt}
                  fill
                  unoptimized
                  priority
                  className="object-cover"
                />
              )}
              <span className="absolute left-4 top-4 bg-signal px-3 py-1.5 font-mono text-[11px] uppercase tracking-widest2 text-paper animate-stamp">
                Live
              </span>
            </div>

            <div className="flex flex-col justify-center">
              <p className="spec-tag">{live.category} · {live.sku}</p>
              <h3 className="mt-3 font-display text-4xl tracking-tightest sm:text-5xl">{live.name}</h3>
              <p className="mt-5 max-w-[52ch] text-ink/70">{live.description}</p>
              <p className="mt-6 font-mono text-2xl">{formatINR(live.priceInPaise)}</p>
              <div className="mt-8 flex flex-wrap gap-3">
                <Link href={`/product/${live.slug}`} className="btn-primary">
                  View &amp; Buy
                </Link>
                <Link href="/shop" className="btn-secondary">
                  Browse The Archive
                </Link>
              </div>
            </div>
          </div>
        ) : (
          <p className="text-ink/60">No product is live right now — check back soon.</p>
        )}
      </section>

      {/* ARCHIVE */}
      <section className="container-ck py-16 sm:py-24">
        <div className="mb-10 flex items-end justify-between">
          <div>
            <p className="eyebrow mb-2">Permanently sold out</p>
            <h2 className="font-display text-3xl tracking-tightest sm:text-5xl">THE ARCHIVE</h2>
          </div>
          <Link href="/shop" className="hidden font-mono text-xs uppercase tracking-widest2 hover:text-signal sm:block">
            View all →
          </Link>
        </div>

        <div className="grid grid-cols-2 gap-x-5 gap-y-10 sm:grid-cols-3 lg:grid-cols-4">
          {archiveOnly.map((p) => (
            <ProductCard key={p.id} product={p as any} />
          ))}
        </div>

        <div className="mt-12 text-center sm:hidden">
          <Link href="/shop" className="btn-secondary">
            View All Archive
          </Link>
        </div>
      </section>
    </>
  );
}
