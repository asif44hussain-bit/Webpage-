import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { formatINR } from "@/lib/money";

export default async function AdminOverviewPage() {
  const [productCount, liveProduct, soldOutCount, orders] = await Promise.all([
    prisma.product.count(),
    prisma.product.findFirst({ where: { status: "LIVE" } }),
    prisma.product.count({ where: { status: "SOLD_OUT" } }),
    prisma.order.findMany({ orderBy: { createdAt: "desc" }, take: 5, include: { customer: true } }),
  ]);

  const stats = [
    { label: "Total Products", value: productCount },
    { label: "Archived (Sold Out)", value: soldOutCount },
    { label: "Live Product", value: liveProduct ? liveProduct.name : "None" },
    { label: "Recent Orders", value: orders.length },
  ];

  return (
    <div>
      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((s) => (
          <div key={s.label} className="border border-ink/10 p-5">
            <p className="spec-tag">{s.label}</p>
            <p className="mt-3 font-display text-2xl tracking-tightest">{s.value}</p>
          </div>
        ))}
      </div>

      <div className="mt-10 flex flex-wrap gap-3">
        <Link href="/admin/products/new" className="btn-primary">Add Product</Link>
        <Link href="/admin/products" className="btn-secondary">Manage Products</Link>
        <Link href="/admin/orders" className="btn-secondary">View Orders</Link>
      </div>

      <div className="mt-12">
        <p className="spec-tag mb-4">Recent orders</p>
        {orders.length === 0 ? (
          <p className="text-sm text-ink/50">No orders yet.</p>
        ) : (
          <div className="divide-y divide-ink/10 border-y border-ink/10">
            {orders.map((o) => (
              <div key={o.id} className="flex flex-wrap items-center justify-between gap-3 py-4 text-sm">
                <span className="font-mono">{o.orderNumber}</span>
                <span>{o.customer.name}</span>
                <span className="spec-tag">{o.status}</span>
                <span className="font-mono">{formatINR(o.subtotalInPaise)}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
