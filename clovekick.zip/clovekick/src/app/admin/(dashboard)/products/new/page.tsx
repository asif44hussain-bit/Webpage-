import ProductForm from "@/components/admin/ProductForm";

export default function NewProductPage() {
  return (
    <div>
      <p className="eyebrow mb-2">New product</p>
      <h2 className="mb-8 font-display text-2xl tracking-tightest">ADD PRODUCT</h2>
      <ProductForm />
    </div>
  );
}
