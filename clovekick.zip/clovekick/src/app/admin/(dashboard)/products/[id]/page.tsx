import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import ProductForm from "@/components/admin/ProductForm";

export default async function EditProductPage({ params }: { params: { id: string } }) {
  const product = await prisma.product.findUnique({
    where: { id: params.id },
    include: { images: { orderBy: { position: "asc" } } },
  });
  if (!product) notFound();

  return (
    <div>
      <p className="eyebrow mb-2">Edit product</p>
      <h2 className="mb-8 font-display text-2xl tracking-tightest">{product.name}</h2>
      <ProductForm
        initial={{
          id: product.id,
          name: product.name,
          sku: product.sku,
          description: product.description,
          story: product.story ?? "",
          priceInRupees: product.priceInPaise / 100,
          category: product.category,
          sizes: product.sizes.join(", "),
          images: product.images.map((i) => i.url).join(", "),
          status: product.status,
          stockCount: product.stockCount,
        }}
      />
    </div>
  );
}
