import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { formatINR } from "@/lib/money";
import ProductRowActions from "@/components/admin/ProductRowActions";

export default async function AdminProductsPage() {
  const products = await prisma.product.findMany({
    orderBy: [{ status: "asc" }, { createdAt: "desc" }],
    include: { images: { take: 1, orderBy: { position: "asc" } } },
  });

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <p className="spec-tag">{products.length} products</p>
        <Link href="/admin/products/new" className="btn-secondary">Add Product</Link>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full min-w-[720px] border-collapse text-sm">
          <thead>
            <tr className="border-b border-ink/10 text-left font-mono text-[11px] uppercase tracking-widest2 text-concrete-dark">
              <th className="py-3 pr-4">Product</th>
              <th className="py-3 pr-4">SKU</th>
              <th className="py-3 pr-4">Category</th>
              <th className="py-3 pr-4">Price</th>
              <th className="py-3 pr-4">Status</th>
              <th className="py-3 pr-4">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-ink/5">
            {products.map((p) => (
              <tr key={p.id}>
                <td className="py-3 pr-4">
                  <Link href={`/admin/products/${p.id}`} className="hover:text-signal">
                    {p.name}
                  </Link>
                </td>
                <td className="py-3 pr-4 font-mono text-xs">{p.sku}</td>
                <td className="py-3 pr-4">{p.category}</td>
                <td className="py-3 pr-4 font-mono">{formatINR(p.priceInPaise)}</td>
                <td className="py-3 pr-4">
                  <span className={p.status === "LIVE" ? "text-signal" : "text-ink/60"}>{p.status}</span>
                </td>
                <td className="py-3 pr-4">
                  <ProductRowActions id={p.id} status={p.status} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
