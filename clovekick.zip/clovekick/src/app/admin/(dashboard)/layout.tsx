import { redirect } from "next/navigation";
import Link from "next/link";
import { getAdminSession } from "@/lib/auth";
import LogoutButton from "@/components/admin/LogoutButton";

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const session = await getAdminSession();
  if (!session) redirect("/admin/login");

  return (
    <div className="container-ck py-10">
      <div className="mb-10 flex flex-wrap items-center justify-between gap-4 border-b border-ink/10 pb-6">
        <div>
          <p className="eyebrow mb-1">Admin</p>
          <h1 className="font-display text-2xl tracking-tightest sm:text-3xl">DASHBOARD</h1>
        </div>
        <nav className="flex flex-wrap items-center gap-6 font-mono text-xs uppercase tracking-widest2">
          <Link href="/admin" className="hover:text-signal">Overview</Link>
          <Link href="/admin/products" className="hover:text-signal">Products</Link>
          <Link href="/admin/orders" className="hover:text-signal">Orders</Link>
          <Link href="/" className="hover:text-signal">View Store</Link>
          <LogoutButton />
        </nav>
      </div>
      {children}
    </div>
  );
}
