import { prisma } from "@/lib/prisma";
import { formatINR } from "@/lib/money";
import OrderStatusSelect from "@/components/admin/OrderStatusSelect";

export default async function AdminOrdersPage() {
  const orders = await prisma.order.findMany({
    orderBy: { createdAt: "desc" },
    include: { customer: true, items: true },
  });

  return (
    <div>
      <p className="spec-tag mb-6">{orders.length} orders</p>

      {orders.length === 0 ? (
        <p className="text-sm text-ink/50">No orders placed yet.</p>
      ) : (
        <div className="space-y-4">
          {orders.map((o) => (
            <div key={o.id} className="border border-ink/10 p-5">
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div>
                  <p className="font-mono text-sm">{o.orderNumber}</p>
                  <p className="mt-1 text-sm text-ink/70">
                    {o.customer.name} · {o.customer.email} · {o.customer.phone}
                  </p>
                  <p className="mt-1 text-xs text-ink/50">
                    {o.customer.address}, {o.customer.city}, {o.customer.state} {o.customer.pincode}
                  </p>
                </div>
                <div className="flex flex-col items-end gap-2">
                  <span className="font-mono text-sm">{formatINR(o.subtotalInPaise)}</span>
                  <OrderStatusSelect id={o.id} status={o.status} />
                </div>
              </div>

              <div className="mt-4 divide-y divide-ink/5 border-t border-ink/5 pt-3">
                {o.items.map((item) => (
                  <div key={item.id} className="flex justify-between py-2 text-xs text-ink/70">
                    <span>{item.nameSnapshot} — Size {item.size} × {item.quantity}</span>
                    <span className="font-mono">{formatINR(item.unitPriceInPaise * item.quantity)}</span>
                  </div>
                ))}
              </div>

              <p className="mt-3 text-[11px] text-ink/40">
                Placed {new Date(o.createdAt).toLocaleString("en-IN")}
              </p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
