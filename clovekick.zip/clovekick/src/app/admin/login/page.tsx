"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function AdminLoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    const res = await fetch("/api/admin/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });
    setLoading(false);
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      setError(data.error || "Login failed.");
      return;
    }
    router.push("/admin");
    router.refresh();
  }

  return (
    <div className="container-ck flex min-h-[70vh] items-center justify-center py-20">
      <form onSubmit={handleSubmit} className="w-full max-w-sm">
        <p className="eyebrow mb-2">Admin</p>
        <h1 className="mb-8 font-display text-3xl tracking-tightest">SIGN IN</h1>

        <label htmlFor="email" className="spec-tag mb-2 block">Email</label>
        <input
          id="email"
          type="email"
          required
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="mb-5 w-full border border-ink/20 bg-transparent px-4 py-3 text-sm outline-none focus:border-ink"
        />

        <label htmlFor="password" className="spec-tag mb-2 block">Password</label>
        <input
          id="password"
          type="password"
          required
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="mb-6 w-full border border-ink/20 bg-transparent px-4 py-3 text-sm outline-none focus:border-ink"
        />

        {error && <p className="mb-4 text-sm text-signal">{error}</p>}

        <button type="submit" disabled={loading} className="btn-primary w-full">
          {loading ? "Signing In…" : "Sign In"}
        </button>
      </form>
    </div>
  );
}
