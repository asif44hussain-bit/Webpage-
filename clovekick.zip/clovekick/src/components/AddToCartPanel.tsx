"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useCartStore } from "@/lib/cart-store";

interface Props {
  productId: string;
  slug: string;
  name: string;
  sku: string;
  sizes: string[];
  unitPriceInPaise: number;
  image: string;
  status: "LIVE" | "SOLD_OUT" | "DRAFT";
}

export default function AddToCartPanel({
  productId,
  slug,
  name,
  sku,
  sizes,
  unitPriceInPaise,
  image,
  status,
}: Props) {
  const [size, setSize] = useState<string | null>(sizes.length === 1 ? sizes[0] : null);
  const [added, setAdded] = useState(false);
  const addItem = useCartStore((s) => s.addItem);
  const router = useRouter();
  const soldOut = status !== "LIVE";

  function handleAdd() {
    if (!size || soldOut) return;
    addItem({ productId, slug, name, sku, size, unitPriceInPaise, image });
    setAdded(true);
    setTimeout(() => setAdded(false), 1800);
  }

  return (
    <div>
      <div>
        <p className="spec-tag mb-3">Size</p>
        <div className="flex flex-wrap gap-2">
          {sizes.map((s) => (
            <button
              key={s}
              disabled={soldOut}
              onClick={() => setSize(s)}
              className={`border px-4 py-2.5 font-mono text-xs uppercase tracking-widest2 transition-colors ${
                size === s ? "border-ink bg-ink text-paper" : "border-ink/30 hover:border-ink"
              } disabled:cursor-not-allowed disabled:opacity-40`}
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      <div className="mt-8 flex flex-col gap-3 sm:flex-row">
        {soldOut ? (
          <button disabled className="btn-primary w-full sm:w-auto">
            Sold Out
          </button>
        ) : (
          <button
            onClick={handleAdd}
            disabled={!size}
            className="btn-primary w-full sm:w-auto"
          >
            {added ? "Added ✓" : size ? "Add to Cart" : "Select a Size"}
          </button>
        )}
        {added && (
          <button onClick={() => router.push("/cart")} className="btn-secondary w-full sm:w-auto">
            View Cart
          </button>
        )}
      </div>

      {soldOut && (
        <p className="mt-4 max-w-[42ch] text-sm text-ink/60">
          This piece is archived and will not be restocked. Explore the current live drop instead.
        </p>
      )}
    </div>
  );
}
