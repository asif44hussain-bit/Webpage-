"use client";

import Link from "next/link";
import { useState } from "react";
import { usePathname } from "next/navigation";
import CartBadge from "./CartBadge";

const NAV = [
  { href: "/shop", label: "Shop" },
  { href: "/#drop", label: "Drops" },
  { href: "/story", label: "Story" },
];

export default function Header() {
  const [menuOpen, setMenuOpen] = useState(false);
  const pathname = usePathname();

  return (
    <header className="sticky top-0 z-50 border-b border-ink/10 bg-paper/90 backdrop-blur">
      <div className="container-ck flex h-16 items-center justify-between sm:h-20">
        <Link
          href="/"
          className="font-display text-xl tracking-tightest sm:text-2xl"
          onClick={() => setMenuOpen(false)}
        >
          CLOVEKICK<span className="align-super text-[10px]">®</span>
        </Link>

        <nav className="hidden items-center gap-8 md:flex">
          {NAV.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={`spec-tag transition-colors hover:text-signal ${
                pathname === item.href ? "text-signal" : "text-ink"
              }`}
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-5">
          <Link href="/shop" aria-label="Search products" className="spec-tag hidden hover:text-signal sm:inline">
            Search
          </Link>
          <Link href="/cart" aria-label="View cart" className="relative spec-tag hover:text-signal">
            Cart
            <CartBadge />
          </Link>
          <button
            className="spec-tag md:hidden"
            aria-label="Toggle menu"
            aria-expanded={menuOpen}
            onClick={() => setMenuOpen((v) => !v)}
          >
            {menuOpen ? "Close" : "Menu"}
          </button>
        </div>
      </div>

      {menuOpen && (
        <nav className="flex flex-col border-t border-ink/10 bg-paper md:hidden">
          {NAV.concat([{ href: "/shop", label: "Search" }]).map((item, i) => (
            <Link
              key={item.label + i}
              href={item.href}
              onClick={() => setMenuOpen(false)}
              className="border-b border-ink/5 px-5 py-4 font-mono text-xs uppercase tracking-widest2"
            >
              {item.label}
            </Link>
          ))}
        </nav>
      )}
    </header>
  );
}
