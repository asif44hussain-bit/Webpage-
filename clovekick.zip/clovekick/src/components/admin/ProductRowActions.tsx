"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function ProductRowActions({
  id,
  status,
}: {
  id: string;
  status: string;
}) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);

  async function setLive() {
    setBusy(true);
    await fetch(`/api/products/${id}/set-live`, { method: "POST" });
    setBusy(false);
    router.refresh();
  }

  async function remove() {
    if (!confirm("Delete this product permanently? This cannot be undone.")) return;
    setBusy(true);
    await fetch(`/api/products/${id}`, { method: "DELETE" });
    setBusy(false);
    router.refresh();
  }

  return (
    <div className="flex items-center gap-4">
      {status !== "LIVE" && (
        <button disabled={busy} onClick={setLive} className="spec-tag hover:text-signal">
          Set Live
        </button>
      )}
      <button disabled={busy} onClick={remove} className="spec-tag text-signal hover:opacity-70">
        Delete
      </button>
    </div>
  );
}
