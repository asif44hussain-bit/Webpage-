"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export interface ProductFormValues {
  id?: string;
  name: string;
  sku: string;
  description: string;
  story: string;
  priceInRupees: number | "";
  category: string;
  sizes: string;
  images: string;
  status: "LIVE" | "SOLD_OUT" | "DRAFT";
  stockCount: number | "";
}

const EMPTY: ProductFormValues = {
  name: "",
  sku: "",
  description: "",
  story: "",
  priceInRupees: "",
  category: "",
  sizes: "S, M, L, XL",
  images: "",
  status: "SOLD_OUT",
  stockCount: 0,
};

export default function ProductForm({ initial }: { initial?: Partial<ProductFormValues> }) {
  const [form, setForm] = useState<ProductFormValues>({ ...EMPTY, ...initial });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const router = useRouter();
  const isEdit = Boolean(form.id);

  function set<K extends keyof ProductFormValues>(key: K, value: ProductFormValues[K]) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError(null);

    const payload = {
      name: form.name,
      sku: form.sku,
      description: form.description,
      story: form.story || undefined,
      priceInPaise: Math.round(Number(form.priceInRupees) * 100),
      category: form.category,
      sizes: form.sizes.split(",").map((s) => s.trim()).filter(Boolean),
      images: form.images.split(",").map((s) => s.trim()).filter(Boolean),
      status: form.status,
      stockCount: Number(form.stockCount) || 0,
    };

    const res = await fetch(isEdit ? `/api/products/${form.id}` : "/api/products", {
      method: isEdit ? "PATCH" : "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    setSaving(false);
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      setError(data.error || "Could not save product.");
      return;
    }
    router.push("/admin/products");
    router.refresh();
  }

  return (
    <form onSubmit={handleSubmit} className="max-w-2xl space-y-5">
      <Field label="Product Name">
        <input required value={form.name} onChange={(e) => set("name", e.target.value)} className="input" />
      </Field>

      <div className="grid grid-cols-2 gap-5">
        <Field label="SKU">
          <input required value={form.sku} onChange={(e) => set("sku", e.target.value)} className="input" />
        </Field>
        <Field label="Category">
          <input required value={form.category} onChange={(e) => set("category", e.target.value)} className="input" />
        </Field>
      </div>

      <Field label="Description">
        <textarea
          required
          rows={4}
          value={form.description}
          onChange={(e) => set("description", e.target.value)}
          className="input"
        />
      </Field>

      <Field label="Story / Notes (optional)">
        <textarea rows={2} value={form.story} onChange={(e) => set("story", e.target.value)} className="input" />
      </Field>

      <div className="grid grid-cols-2 gap-5">
        <Field label="Price (INR)">
          <input
            required
            type="number"
            min={0}
            step="0.01"
            value={form.priceInRupees}
            onChange={(e) => set("priceInRupees", e.target.value === "" ? "" : Number(e.target.value))}
            className="input"
          />
        </Field>
        <Field label="Stock Count">
          <input
            type="number"
            min={0}
            value={form.stockCount}
            onChange={(e) => set("stockCount", e.target.value === "" ? "" : Number(e.target.value))}
            className="input"
          />
        </Field>
      </div>

      <Field label="Sizes (comma separated)">
        <input value={form.sizes} onChange={(e) => set("sizes", e.target.value)} className="input" />
      </Field>

      <Field label="Image URLs (comma separated — /products/your-file.svg or full URL)">
        <textarea rows={2} value={form.images} onChange={(e) => set("images", e.target.value)} className="input" />
      </Field>

      <Field label="Status">
        <select value={form.status} onChange={(e) => set("status", e.target.value as any)} className="input">
          <option value="SOLD_OUT">Sold Out (Archive)</option>
          <option value="LIVE">Live (marks any other live product Sold Out)</option>
          <option value="DRAFT">Draft (hidden from store)</option>
        </select>
      </Field>

      {error && <p className="text-sm text-signal">{error}</p>}

      <button type="submit" disabled={saving} className="btn-primary">
        {saving ? "Saving…" : isEdit ? "Save Changes" : "Create Product"}
      </button>

      <style jsx>{`
        .input {
          width: 100%;
          border: 1px solid rgba(18, 18, 18, 0.2);
          background: transparent;
          padding: 0.75rem 1rem;
          font-size: 0.875rem;
          outline: none;
        }
        .input:focus {
          border-color: #121212;
        }
      `}</style>
    </form>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="spec-tag mb-2 block">{label}</label>
      {children}
    </div>
  );
}
