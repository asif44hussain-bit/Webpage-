"use client";

import { useEffect, useState } from "react";
import { useCartStore } from "@/lib/cart-store";

export default function CartBadge() {
  const [mounted, setMounted] = useState(false);
  const count = useCartStore((s) => s.totalQuantity());

  // Avoid hydration mismatch: localStorage-backed store only reflects real
  // state after mount.
  useEffect(() => setMounted(true), []);
  if (!mounted || count === 0) return null;

  return (
    <span className="ml-1 inline-flex h-4 min-w-[16px] items-center justify-center rounded-full bg-signal px-1 font-mono text-[10px] text-paper">
      {count}
    </span>
  );
}
