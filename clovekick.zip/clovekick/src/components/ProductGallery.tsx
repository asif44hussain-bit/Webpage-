"use client";

import Image from "next/image";
import { useState } from "react";

export default function ProductGallery({
  images,
  soldOut,
}: {
  images: { url: string; alt: string }[];
  soldOut: boolean;
}) {
  const [active, setActive] = useState(0);
  const current = images[active] ?? images[0];

  return (
    <div>
      <div className="relative aspect-[4/5] overflow-hidden bg-concrete/20">
        {current && (
          <Image
            src={current.url}
            alt={current.alt}
            fill
            unoptimized
            priority
            className={`object-cover transition-opacity duration-300 ${soldOut ? "grayscale-[35%] opacity-85" : ""}`}
          />
        )}
        {soldOut && (
          <span className="absolute left-4 top-4 -rotate-3 border border-ink bg-paper/95 px-3 py-1.5 font-mono text-[11px] uppercase tracking-widest2 animate-stamp">
            Sold Out
          </span>
        )}
      </div>
      {images.length > 1 && (
        <div className="mt-4 grid grid-cols-4 gap-3">
          {images.map((img, i) => (
            <button
              key={img.url}
              onClick={() => setActive(i)}
              aria-label={`Show image ${i + 1}`}
              className={`relative aspect-square overflow-hidden bg-concrete/20 outline outline-1 transition-opacity ${
                i === active ? "outline-ink opacity-100" : "outline-transparent opacity-60 hover:opacity-100"
              }`}
            >
              <Image src={img.url} alt={img.alt} fill unoptimized className="object-cover" />
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
