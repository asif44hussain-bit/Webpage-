import Link from "next/link";
import Image from "next/image";
import { formatINR } from "@/lib/money";

export interface ProductCardData {
  slug: string;
  name: string;
  priceInPaise: number;
  status: "LIVE" | "SOLD_OUT" | "DRAFT";
  category: string;
  sku: string;
  images: { url: string; alt: string }[];
}

export default function ProductCard({ product }: { product: ProductCardData }) {
  const image = product.images[0];
  const soldOut = product.status === "SOLD_OUT";

  return (
    <Link
      href={`/product/${product.slug}`}
      className="group block"
    >
      <div className="relative aspect-[4/5] overflow-hidden bg-concrete/20">
        {image && (
          <Image
            src={image.url}
            alt={image.alt}
            fill
            unoptimized
            className={`object-cover transition-transform duration-500 ease-out group-hover:scale-[1.04] ${
              soldOut ? "grayscale-[35%] opacity-80" : ""
            }`}
            sizes="(max-width: 768px) 50vw, 25vw"
          />
        )}

        {product.status === "LIVE" && (
          <span className="absolute left-3 top-3 bg-signal px-2.5 py-1 font-mono text-[10px] uppercase tracking-widest2 text-paper">
            Live
          </span>
        )}
        {soldOut && (
          <span className="absolute left-3 top-3 -rotate-3 border border-ink bg-paper/95 px-2.5 py-1 font-mono text-[10px] uppercase tracking-widest2 text-ink">
            Sold Out
          </span>
        )}
      </div>

      <div className="mt-3 flex items-start justify-between gap-2">
        <div>
          <h3 className="text-sm font-medium leading-tight">{product.name}</h3>
          <p className="spec-tag mt-1">{product.category} · {product.sku}</p>
        </div>
        <p className="whitespace-nowrap font-mono text-sm">{formatINR(product.priceInPaise)}</p>
      </div>
    </Link>
  );
}
