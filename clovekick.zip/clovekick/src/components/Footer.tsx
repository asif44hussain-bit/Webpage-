import Link from "next/link";

export default function Footer() {
  return (
    <footer className="border-t border-ink/10 bg-ink text-paper">
      <div className="container-ck grid gap-10 py-14 sm:grid-cols-2 lg:grid-cols-4">
        <div>
          <div className="font-display text-lg tracking-tightest">
            CLOVEKICK<span className="align-super text-[9px]">®</span>
          </div>
          <p className="mt-3 max-w-[26ch] text-sm text-paper/60">
            Original streetwear. Limited drops. One product live at a time.
          </p>
        </div>

        <div>
          <div className="eyebrow text-paper/40">Shop</div>
          <ul className="mt-4 space-y-2 text-sm">
            <li><Link href="/shop" className="hover:text-signal">All products</Link></li>
            <li><Link href="/#drop" className="hover:text-signal">Current drop</Link></li>
            <li><Link href="/shop?category=all" className="hover:text-signal">The Archive</Link></li>
          </ul>
        </div>

        <div>
          <div className="eyebrow text-paper/40">Company</div>
          <ul className="mt-4 space-y-2 text-sm">
            <li><Link href="/story" className="hover:text-signal">Our story</Link></li>
            <li><Link href="/cart" className="hover:text-signal">Cart</Link></li>
            <li><Link href="/admin" className="hover:text-signal">Admin</Link></li>
          </ul>
        </div>

        <div>
          <div className="eyebrow text-paper/40">Get notified</div>
          <p className="mt-4 text-sm text-paper/60">
            The next drop isn&apos;t announced until it&apos;s live. Check back — no restocks, no reissues.
          </p>
        </div>
      </div>
      <div className="border-t border-paper/10 py-5">
        <div className="container-ck flex flex-col gap-2 text-[11px] text-paper/40 sm:flex-row sm:justify-between">
          <span>© {new Date().getFullYear()} CLOVEKICK. All rights reserved.</span>
          <span>Designed &amp; built independently. Not affiliated with any other retailer.</span>
        </div>
      </div>
    </footer>
  );
}
