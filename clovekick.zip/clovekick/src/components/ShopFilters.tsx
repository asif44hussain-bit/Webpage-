"use client";

import { useRouter, useSearchParams, usePathname } from "next/navigation";
import { useState, useTransition } from "react";

const SORTS = [
  { value: "newest", label: "Newest" },
  { value: "price-asc", label: "Price: Low to High" },
  { value: "price-desc", label: "Price: High to Low" },
];

export default function ShopFilters({ categories }: { categories: string[] }) {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const [pending, startTransition] = useTransition();
  const [query, setQuery] = useState(searchParams.get("q") ?? "");

  function updateParam(key: string, value: string) {
    const params = new URLSearchParams(searchParams.toString());
    if (value) params.set(key, value);
    else params.delete(key);
    startTransition(() => router.push(`${pathname}?${params.toString()}`));
  }

  return (
    <div className="mb-10 flex flex-col gap-5 border-b border-ink/10 pb-8 sm:flex-row sm:items-end sm:justify-between">
      <form
        onSubmit={(e) => {
          e.preventDefault();
          updateParam("q", query);
        }}
        className="flex w-full max-w-sm items-center border-b border-ink pb-2 sm:w-72"
      >
        <input
          type="search"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search products, SKU..."
          className="w-full bg-transparent font-mono text-sm outline-none placeholder:text-concrete-dark"
          aria-label="Search products"
        />
        <button type="submit" className="spec-tag hover:text-signal">Go</button>
      </form>

      <div className="flex flex-wrap items-center gap-4">
        <select
          value={searchParams.get("category") ?? "all"}
          onChange={(e) => updateParam("category", e.target.value === "all" ? "" : e.target.value)}
          className="border border-ink/20 bg-transparent px-3 py-2 font-mono text-xs uppercase tracking-widest2"
          aria-label="Filter by category"
        >
          <option value="all">All Categories</option>
          {categories.map((c) => (
            <option key={c} value={c}>{c}</option>
          ))}
        </select>

        <select
          value={searchParams.get("sort") ?? "newest"}
          onChange={(e) => updateParam("sort", e.target.value)}
          className="border border-ink/20 bg-transparent px-3 py-2 font-mono text-xs uppercase tracking-widest2"
          aria-label="Sort products"
        >
          {SORTS.map((s) => (
            <option key={s.value} value={s.value}>{s.label}</option>
          ))}
        </select>
        {pending && <span className="spec-tag animate-pulse">Updating…</span>}
      </div>
    </div>
  );
}
