import { prisma } from "./prisma";
import { Prisma, ProductStatus } from "@prisma/client";

export type SortOption = "newest" | "price-asc" | "price-desc";

export interface ProductQuery {
  q?: string;
  category?: string;
  sort?: SortOption;
}

const SORT_MAP: Record<SortOption, Prisma.ProductOrderByWithRelationInput> = {
  newest: { createdAt: "desc" },
  "price-asc": { priceInPaise: "asc" },
  "price-desc": { priceInPaise: "desc" },
};

export async function getLiveProduct() {
  return prisma.product.findFirst({
    where: { status: "LIVE" },
    include: { images: { orderBy: { position: "asc" } } },
  });
}

export async function listProducts(query: ProductQuery = {}) {
  const { q, category, sort = "newest" } = query;

  const where: Prisma.ProductWhereInput = {
    status: { not: "DRAFT" },
  };
  if (category && category !== "all") {
    where.category = category;
  }
  if (q) {
    where.OR = [
      { name: { contains: q, mode: "insensitive" } },
      { description: { contains: q, mode: "insensitive" } },
      { sku: { contains: q, mode: "insensitive" } },
      { category: { contains: q, mode: "insensitive" } },
    ];
  }

  return prisma.product.findMany({
    where,
    orderBy: SORT_MAP[sort],
    include: { images: { orderBy: { position: "asc" } } },
  });
}

export async function getProductBySlug(slug: string) {
  return prisma.product.findUnique({
    where: { slug },
    include: { images: { orderBy: { position: "asc" } } },
  });
}

export async function getRelatedProducts(category: string, excludeId: string, take = 4) {
  return prisma.product.findMany({
    where: { category, id: { not: excludeId }, status: { not: "DRAFT" } },
    take,
    orderBy: { createdAt: "desc" },
    include: { images: { orderBy: { position: "asc" } } },
  });
}

export async function getCategories() {
  const rows = await prisma.product.findMany({
    where: { status: { not: "DRAFT" } },
    select: { category: true },
    distinct: ["category"],
  });
  return rows.map((r) => r.category).sort();
}

/**
 * Marks `productId` LIVE and demotes any previously-LIVE product to SOLD_OUT,
 * inside a single transaction so the "only one live product" invariant can
 * never be violated by a race.
 */
export async function setProductLive(productId: string) {
  return prisma.$transaction(async (tx) => {
    await tx.product.updateMany({
      where: { status: "LIVE", id: { not: productId } },
      data: { status: ProductStatus.SOLD_OUT },
    });
    return tx.product.update({
      where: { id: productId },
      data: { status: ProductStatus.LIVE },
    });
  });
}
